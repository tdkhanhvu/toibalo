
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd"><!-- Avatar Framework 1.0.0 pro -->
<html lang="en-gb" dir="ltr" >
<head>
<base href="http://www.beautiful-templates.com/demo/templates-joomla/st_vela/index.php/home" />
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta name="description" content="ST Vela - wonderful onepage joomla" />
<meta name="generator" content="Joomla! - Open Source Content Management" />
<title>Home</title>
<link href="http://www.beautiful-templates.com/demo/templates-joomla/st_vela/index.php/home" rel="canonical" />
<link href="/demo/templates-joomla/st_vela/index.php/home?format=feed&amp;type=rss" rel="alternate" type="application/rss+xml" title="RSS 2.0" />
<link href="/demo/templates-joomla/st_vela/index.php/home?format=feed&amp;type=atom" rel="alternate" type="application/atom+xml" title="Atom 1.0" />
<link rel="stylesheet" href="http://www.beautiful-templates.com/demo/templates-joomla/st_vela//plugins/system/st_megamenu/assets/css/megamenu.css" type="text/css" />
<link rel="stylesheet" href="/demo/templates-joomla/st_vela/media/jui/css/bootstrap.min.css" type="text/css" />
<link rel="stylesheet" href="/demo/templates-joomla/st_vela/media/jui/css/bootstrap-responsive.min.css" type="text/css" />
<link rel="stylesheet" href="/demo/templates-joomla/st_vela/media/jui/css/bootstrap-extended.css" type="text/css" />
<link rel="stylesheet" href="/demo/templates-joomla/st_vela/plugins/system/ytshortcodes/assets/css/awesome/font-awesome.css" type="text/css" />
<link rel="stylesheet" href="/demo/templates-joomla/st_vela/plugins/system/ytshortcodes/assets/css/awesome/glyphicon.css" type="text/css" />
<link rel="stylesheet" href="/demo/templates-joomla/st_vela/plugins/system/ytshortcodes/assets/css/shortcodes.css" type="text/css" />
<link rel="stylesheet" href="http://www.beautiful-templates.com/demo/templates-joomla/st_vela/modules/mod_bt_googlemaps/tmpl/css/style.css" type="text/css" />
<link rel="stylesheet" href="/demo/templates-joomla/st_vela/modules/mod_st_content_showcase/exts/layer_slider/assets/css/style.css" type="text/css" />
<link rel="stylesheet" href="/demo/templates-joomla/st_vela/modules/mod_st_content_showcase/exts/layer_slider/assets/css/_slide/style.css" type="text/css" />
<link rel="stylesheet" href="/demo/templates-joomla/st_vela/modules/mod_st_content_showcase/exts/layer_slider/assets/effects/breaking_news/style.css" type="text/css" />
<link rel="stylesheet" href="/demo/templates-joomla/st_vela/media/system/css/modal.css" type="text/css" />
<link rel="stylesheet" href="/demo/templates-joomla/st_vela/modules/mod_st_content_showcase/exts/wall/layout.css" type="text/css" />
<link rel="stylesheet" href="/demo/templates-joomla/st_vela/modules/mod_st_content_showcase/assets/lightbox/jquery.fancybox-1.3.4.css" type="text/css" />
<link rel="stylesheet" href="/demo/templates-joomla/st_vela/modules/mod_st_content_showcase/exts/wall/styles/grey.css" type="text/css" />
<script src="/demo/templates-joomla/st_vela/media/jui/js/jquery.min.js" type="text/javascript"></script>
<script src="/demo/templates-joomla/st_vela/media/jui/js/jquery-noconflict.js" type="text/javascript"></script>
<script src="/demo/templates-joomla/st_vela/media/jui/js/jquery-migrate.min.js" type="text/javascript"></script>
<script src="http://www.beautiful-templates.com/demo/templates-joomla/st_vela//plugins/system/st_megamenu/assets/js/megamenu.js" type="text/javascript"></script>
<script src="/demo/templates-joomla/st_vela/media/system/js/tabs-state.js" type="text/javascript"></script>
<script src="/demo/templates-joomla/st_vela/media/system/js/caption.js" type="text/javascript"></script>
<script src="/demo/templates-joomla/st_vela/media/jui/js/bootstrap.min.js" type="text/javascript"></script>
<script src="/demo/templates-joomla/st_vela/media/system/js/mootools-core.js" type="text/javascript"></script>
<script src="/demo/templates-joomla/st_vela/media/system/js/core.js" type="text/javascript"></script>
<script src="/demo/templates-joomla/st_vela/media/system/js/mootools-more.js" type="text/javascript"></script>
<script src="http://www.beautiful-templates.com/demo/templates-joomla/st_vela/plugins/system/ytshortcodes/assets/js/jquery.prettyPhoto.js" type="text/javascript"></script>
<script src="http://www.beautiful-templates.com/demo/templates-joomla/st_vela/plugins/system/ytshortcodes/assets/js/shortcodes.js" type="text/javascript"></script>
<script src="//maps.google.com/maps/api/js?sensor=true&language=en-GB" type="text/javascript"></script>
<script src="http://www.beautiful-templates.com/demo/templates-joomla/st_vela/modules/mod_bt_googlemaps/tmpl/js/btbase64.min.js" type="text/javascript"></script>
<script src="http://www.beautiful-templates.com/demo/templates-joomla/st_vela/modules/mod_bt_googlemaps/tmpl/js/default.js" type="text/javascript"></script>
<script src="/demo/templates-joomla/st_vela/modules/mod_st_content_showcase/exts/layer_slider/assets/js/jquery.sequence.js" type="text/javascript"></script>
<script src="/demo/templates-joomla/st_vela/media/system/js/modal.js" type="text/javascript"></script>
<script src="/demo/templates-joomla/st_vela/modules/mod_st_content_showcase/assets/js/modernizr.custom.97074.js" type="text/javascript"></script>
<script src="/demo/templates-joomla/st_vela/modules/mod_st_content_showcase/exts/wall/isotope.js" type="text/javascript"></script>
<script src="/demo/templates-joomla/st_vela/modules/mod_st_content_showcase/exts/wall/load-images.js" type="text/javascript"></script>
<script src="/demo/templates-joomla/st_vela/modules/mod_st_content_showcase/exts/wall/resize.js" type="text/javascript"></script>
<script src="/demo/templates-joomla/st_vela/modules/mod_st_content_showcase/assets/js/jquery.mousewheel.min.js" type="text/javascript"></script>
<script src="/demo/templates-joomla/st_vela/modules/mod_st_content_showcase/assets/lightbox/jquery.fancybox-1.3.4.pack.js" type="text/javascript"></script>
<script type="text/javascript">
jQuery(window).on('load',  function() {
    new JCaption('img.caption');
});

jQuery.noConflict();
(function($){
    $(document).ready(function(){
        var layerOptions = {"width":"100%","height":"433px","cols":"2","effects":"breaking_news","layout":"_slide.php","html":true,"autoPlay":false,"autoPlayDelay":"3000","nav":false,"pagination":true,"thumbnail_image":false};

        if (layerOptions.nav) {
            layerOptions.nextButton = "#53415ba137313 .sequence-next";
            layerOptions.prevButton = "#53415ba137313 .sequence-prev";
        }

        //layerOptions.preventDelayWhenReversingAnimations = true;
        //layerOptions.transitionThreshold = 3000;

        if (layerOptions.pagination) { layerOptions.pagination = "#53415ba137313 .sequence-pagination" }
        var options53415ba137313 = layerOptions;

        var mySequence53415ba137313 = $("#53415ba137313").sequence(options53415ba137313).data("sequence");
    });
})(jQuery);


jQuery.noConflict();
(function($){
    $(document).ready(function(){
        var layerOptions = {"width":"100%","height":"300px","cols":"1","effects":"breaking_news","layout":"_slide.php","html":true,"autoPlay":false,"autoPlayDelay":"3000","nav":true,"pagination":true,"thumbnail_image":true};

        if (layerOptions.nav) {
            layerOptions.nextButton = "#53415ba13d3df .sequence-next";
            layerOptions.prevButton = "#53415ba13d3df .sequence-prev";
        }

        //layerOptions.preventDelayWhenReversingAnimations = true;
        //layerOptions.transitionThreshold = 3000;

        if (layerOptions.pagination) { layerOptions.pagination = "#53415ba13d3df .sequence-pagination" }
        var options53415ba13d3df = layerOptions;

        var mySequence53415ba13d3df = $("#53415ba13d3df").sequence(options53415ba13d3df).data("sequence");
    });
})(jQuery);

window.addEvent('domready', function() {

    SqueezeBox.initialize({});
    SqueezeBox.assign($$('a.modal'), {
        parse: 'rel'
    });
});

jQuery.noConflict();
(function($){
    var wallParams = {"copyright":"1","moduleclass_sfx":"st-our-work","item_id":"105","count":"20","extension":"wall","source":"article","title":"1","title_link":"0","introtext":"0","introtext_length":0,"image":"1","image_link":"1","category":"0","auto_find_image":"1","seo_link":"1","article_catid":["9","10","11","12","13","14"],"article_featured":"0","article_ordering":"a.publish_up","k2_catid":"","k2_itemsOrdering":"","k2_image_size":"M","folder_sync":"0","folder_image":[""],"folder_ititle":[""],"folder_ilink":[""],"folder_iintrotext":[""],"virtuemart_product_group":"featured","virtuemart_category":"","phocagallery_category":"","phocagallery_ordering":"1","joomgallery_category":"","joomgallery_ordering":"rand()","jgallery_catid":"","jgallery_ordering":"rand()","wall_grid_cols":"5","wall_grid_cols_320":"1","wall_grid_cols_480":"1","wall_grid_cols_767":"3","wall_item_width":"1","wall_category":"1","wall_style":"grey.css","wall_modal":"1","wall_show_content":"1","wall_created_date":"1","accoridion_cols":"3","news_horizonal_cols":"3","news_horizonal_readmore":"","news_horizonal_pre_text":"","news_horizonal_image":"1","news_horizonal_date":"1","flex_width":"100%","flex_animation":"slide","flex_direction":"horizontal","flex_animationLoop":"1","flex_smoothHeight":"0","flex_slideshow":"1","flex_slideshowSpeed":"7000","flex_animationSpeed":"600","flex_initDelay":"0","flex_pauseOnAction":"1","flex_pauseOnHover":"0","flex_useCSS":"1","flex_touch":"1","flex_controlNav":"1","flex_directionNav":"1","flex_preText":"Preview","flex_nextText":"Next","flex_keyboard":"1","flex_multipleKeyboard":"0","flex_mousewheel":"0","flex_pausePlay":"0","flex_pauseText":"","flex_playText":"","flex_itemWidth":"0","flex_minItems":"0","flex_maxItems":"0","flex_move":"0","flex_modal":"0","galleria_width":"100%","galleria_height":"450px","galleria_autoplay":"5000","galleria_easing":"galleria","galleria_fullscreenDoubleTap":"1","galleria_imageCrop":"false","galleria_imageMargin":"0","galleria_imagePan":"true","galleria_imagePanSmoothness":"8","galleria_imagePosition":"center","galleria_initialTransition":"slide","galleria_transition":"fade","galleria_trueFullscreen":"true","galleria_transitionSpeed":"400","galleria_pauseOnInteraction":"true","galleria_preload":"2","galleria_queue":"true","galleria_responsive":"true","galleria_show":"0","galleria_showCounter":"true","galleria_showInfo":"true","galleria_showImageNav":"true","galleria_swipe":"true","galleria_thumbnails":"true","galleria_thumbMargin":"0","galleria_thumbQuality":"true","slider_content_width":"100%","slider_content_height":"","slider_content_cols":3,"slider_content_readmore":"","slider_content_image":"1","slider_content_date":"1","layer_slider_width":"100%","layer_slider_height":"300px","layer_slider_cols":"1","layer_slider_effects":"breaking_news","layer_slider_layout":"_slide.php","layer_slider_html":"true","layer_slider_autoPlay":"true","layer_slider_autoPlayDelay":"3000","layer_slider_nav":"true","layer_slider_pagination":"true","layer_slider_thumbnail_image":"true","module_tag":"div","bootstrap_size":"0","header_tag":"h3","header_class":"","style":"0"};
    var show_content = parseInt('1');
    setCols = function (contain, containerWidth, cols)
    {
        var widthWindow = $(window).width();

        if (widthWindow <= 320) {
            cols = wallParams.wall_grid_cols_320;
        } else if (widthWindow <= 480) {
            cols = wallParams.wall_grid_cols_480;
        } else if (widthWindow <= 767) {
            cols = wallParams.wall_grid_cols_767;
        }

        if (widthWindow <= 320) {
            itemWidth = containerWidth/wallParams.wall_grid_cols_320;
        } else if (widthWindow <= 480) {
            itemWidth = containerWidth/wallParams.wall_grid_cols_480;
        } else if (widthWindow <= 767){
            itemWidth = containerWidth/wallParams.wall_grid_cols_767;
        } else {
            itemWidth = containerWidth/cols - 0.1;
        }

        $(contain + ' .item').each(function(el)
        {
            if (wallParams.wall_item_width == 'auto') {
                width = $(this).width();
                offset = Math.round(width/itemWidth);
                $(this).css('width', itemWidth * offset);
            } else {
                $(this).css('width', itemWidth);
            }
        });

        return cols;
    }

    $(document).ready(function(){
        var wrapper = $('#53415ba15888f');
        var contain = wrapper.find('.layout-wall');

        contain.imagesLoaded(function()
        {
            var cols = setCols('#53415ba15888f', contain.width(), wallParams.wall_grid_cols);
            var options = {};
            if (wallParams.wall_fit_row != '0') {
                options.layoutMode = 'fitRows';
            }

            contain.isotope(options);

            // update columnWidth on window resize
            $(window).on('throttledresize', function( event ) {
                cols = setCols('#53415ba15888f', contain.width(), wallParams.wall_grid_cols);
            });

            $('a[rel=53415ba15888f]').fancybox({
                'titlePosition'		: 'outside',
                'overlayColor'		: '#000',
                'overlayOpacity'	: 0.9,
                'titlePosition' 	: 'over'
            });
        });

        // category
        wrapper.find('.category-wall span[data-filter="all"]').addClass('current');
        wrapper.find('.category-wall span').each(function()
        {
            $(this).click(function()
            {
                var className = $(this).attr('data-filter');
                if (className == 'all') {
                    className = 'item';
                }

                contain.isotope({ filter: '.' + className});
                wrapper.find('.category-wall span').removeClass('current');
                $(this).addClass('current');

                if(show_content == 1){
                    //Remove content when click category
                    wrapper.find('#content-section').removeClass('open');
                    contain.find('.item').removeClass('active');
                    $('#content-section .main-content').find('.item-content').removeClass('active');
                }
            });
        });

        if(show_content == 1){

            //Set content
            list_item = contain.find('.item');
            var count =  list_item.length;

            var item_content = $('#content-section .main-content').find('.item-content');

            var our_work = $('.st-our-work .category-wall').offset().top,
                our_work_H = $('.st-our-work .category-wall').height();

            var menuH = $('#avatar-header-inside-block').height();

            var eindex = 0;
            $(list_item).click(function(){
                wrapper.find('#content-section').addClass('open');
                $('#content-section').addClass('click');
                list_item.removeClass('active');
                $(this).addClass('active');

                eindex = list_item.index(this);


                $('body,html').animate({
                    scrollTop: our_work - menuH + our_work_H
                }, 1000, function(){
                    $(this).addClass('active');
                    item_content.removeClass('active');
                    item_content.eq(eindex).addClass('active');
                });

                setTimeout(function(){
                    $('#content-section').removeClass('click');
                }, 1200);
            });

            //Event with next button
            $('#53415ba15888f #content-section .next').click(function(){
                $('#content-section').addClass('click');
                eindex++;
                if(eindex==count){eindex=0;}

                $('body,html').animate({
                    scrollTop: our_work - menuH + our_work_H
                }, 1000, function(){
                    list_item.removeClass('active');
                    list_item.eq(eindex).addClass('active');
                    item_content.removeClass('active');
                    item_content.eq(eindex).addClass('active');
                });

                setTimeout(function(){
                    $('#content-section').removeClass('click');
                }, 1200);
            });


            //Event with prev button
            $('#53415ba15888f #content-section .prev').click(function(){
                $('#content-section').addClass('click');
                eindex--;
                if(eindex==-1){eindex=count-1;}

                $('body,html').animate({
                    scrollTop: our_work - menuH  + our_work_H
                }, 1000, function(){
                    list_item.removeClass('active');
                    list_item.eq(eindex).addClass('active');
                    item_content.removeClass('active');
                    item_content.eq(eindex).addClass('active');
                });

                setTimeout(function(){
                    $('#content-section').removeClass('click');
                }, 1200);
            });

            $('#53415ba15888f #content-section #close').click(function(){
                list_item.removeClass('active');
                item_content.removeClass('active');
                wrapper.find('#content-section').removeClass('open');
                return false;
            });
            return false;
        }

    });
})(jQuery);

</script>
<link rel="stylesheet" href="/demo/templates-joomla/st_vela/templates/system/css/system.css" type="text/css"/>
<link rel="stylesheet" href="/demo/templates-joomla/st_vela/templates/system/css/general.css" type="text/css"/>
<link rel="stylesheet" href="/demo/templates-joomla/st_vela/templates/system/css/editor.css" type="text/css"/>
<link rel="stylesheet" href="/demo/templates-joomla/st_vela/templates/st_vela/core/assets/css/layout.css" type="text/css"/>
<link rel="stylesheet" href="/demo/templates-joomla/st_vela/templates/st_vela/core/assets/css/core_joomla.css" type="text/css"/>
<link rel="stylesheet" href="/demo/templates-joomla/st_vela/templates/st_vela/core/assets/css/responsive.css" type="text/css"/>
<link rel="stylesheet" href="/demo/templates-joomla/st_vela/templates/st_vela/css/template.css" type="text/css"/>
<link rel="stylesheet" href="/demo/templates-joomla/st_vela/templates/st_vela/css/typography.css" type="text/css"/>
<link rel="stylesheet" href="/demo/templates-joomla/st_vela/templates/st_vela/showcases/colorfull/css/style.css" type="text/css"/>
<script src="/demo/templates-joomla/st_vela/templates/st_vela/js/avatar-template.js" type="text/javascript"></script>
<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0">

<script stype="text/javascript">
    jQuery.noConflict();
    (function($){
        $(document).ready(function() {
            var goToTop = $('#avatar-go-to-top');
            goToTop.hide();

            // fade in #back-top
            $(function () {
                $(window).scroll(function () {
                    if ($(this).scrollTop() > 100) {
                        goToTop.fadeIn();
                    } else {
                        goToTop.fadeOut();
                    }
                });

                // scroll body to 0px on click
                goToTop.click(function () {
                    $('body,html').animate({
                        scrollTop: 0
                    }, 800);
                    return false;
                });
            });
        });
    })(jQuery)
</script>

<script type="text/javascript">
    jQuery.noConflict();
    (function($){
        $(document).ready(function()
        {
            avatarTemplate.url.base = "http://www.beautiful-templates.com/demo/templates-joomla/st_vela/";
            avatarTemplate.template.name = "st_vela";
            avatarTemplate.template.params = {"google_analytics":"UA-37230411-1","copyright":"0","template_panel_setting":"1","active_responsive":"1","load_jquery":"1","template_showcase":"-1","template_background":"0","doctype":"5","show_main_body":"1","hide_menu_items":["0"],"show_message":"0","404_article":"31","404_itemid":111,"template_width":"1140px","avatar_header_block":"block-default-width","avatar_header_inside_block":"block-default-width","avatar_tool_block":"block-default-width","avatar_body_top_block":"block-default-width","avatar_body_middle_block":"block-default-width","avatar_body_bottom_block":"block-default-width","avatar_footer_inside_block":"block-default-width","avatar_footer_block":"block-default-width","avatar_full_1_block":"block-default-width","avatar_full_2_block":"block-default-width","avatar_full_3_block":"block-default-width","avatar_full_4_block":"block-default-width","avatar_full_5_block":"block-default-width","avatar_full_6_block":"block-default-width","top_left":25,"top_right":75,"promo_top_left":33.33,"promo_top_right":33.33,"promo_bottom_left":33.33,"promo_bottom_right":33.33,"left":23,"right":32,"inner_left":23,"inner_right":23,"footer_left":33.33,"footer_right":33.33,"link_color":"","hover_color":"","body_font":"","menu_font":"","google_font_api":"0","google_font_api_key":"","google_font_content":"","customize_css":"","go_to_top":"1","go_to_top_text":"","go_to_top_css":"","css3_effect":"1","css3_effect_scroll":".avatar-css3-effect-scroll"};
            avatarTemplate.image.initEffects();
            avatarTemplate.layout.init();
            avatarTemplate.settingPanel.init();
            avatarTemplate.menu.init();
            avatarTemplate.css3effect.init();
        });
    })(jQuery)
</script>
<style type="text/css">
    body { background-image: url(http://www.beautiful-templates.com/demo/templates-joomla/st_vela/templates/st_vela/backgrounds/);}
</style>		<style type="text/css">
    .avatar-wrapper{
        width: 1140px;
        margin: auto;
    }

    #avatar-pos-top-left {
        width: 25%;
    }
    #avatar-pos-top-middle {
        width: 0%;
    }
    #avatar-pos-top-right {
        width: 75%;
    }

    #avatar-pos-footer-left {
        width: 33.33%;
    }
    #avatar-pos-footer-middle {
        width: 33.34%;
    }
    #avatar-pos-footer-right {
        width: 33.33%;
    }

    #avatar-pos-promo-top-left {
        width: 33.33%;
    }
    #avatar-pos-promo-top-middle {
        width: 100%;
    }
    #avatar-pos-promo-top-right {
        width: 33.33%;
    }

    #avatar-pos-promo-bottom-left {
        width: 33.33%;
    }
    #avatar-pos-promo-bottom-middle {
        width: 100%;
    }
    #avatar-pos-promo-bottom-right {
        width: 33.33%;
    }

    #avatar-left {
        width: 23%;
    }
    #avatar-right {
        width: 32%;
    }
    #avatar-content {
        width: 100%;
    }
    #avatar-pos-inner-left {
        width: 23%;
    }
    #avatar-pos-inner-right {
        width: 23%;
    }

    #avatar-main-content{
        width: 100%;
    }
</style>

<script type="text/javascript">
    var _gaq = _gaq || [];
    _gaq.push(["_setAccount", "UA-37230411-1"]);
    _gaq.push(["_trackPageview"]);

    (function() {
        var ga = document.createElement("script"); ga.type = "text/javascript"; ga.async = true;
        ga.src = ("https:" == document.location.protocol ? "https://ssl" : "http://www") + ".google-analytics.com/ga.js";
        var s = document.getElementsByTagName("script")[0]; s.parentNode.insertBefore(ga, s);
    })();

</script>	</head>
<body id="avatar-template" class="avatar-responsive css3-effect  st-menu-home home-page">

<div id="avatar-full-1-example-block">
<div class="avatar-wrapper1 ">
<div id="109" class="avatar-module st-our-work">
<h3 class="st-module-heading"><span></spam><span>Our Work</span></span></h3>
<div class="st-module-content">
<div class="st-content-showcase-wall grey"  id="53415ba15888f">
<div class="category-wall">
    <span data-filter="all">All</span>

    <span data-filter="design">Design</span>

    <span data-filter="logo">Logo</span>

    <span data-filter="wordpress">Wordpress</span>

    <span data-filter="photography">Photography</span>

    <span data-filter="illustrations">Illustrations</span>

    <span data-filter="video">Video</span>
</div>

<!-- Load content -->
<div id="content-section">
    <div id="loader"></div>
    <div class="main-content">
        <div class="item-content">
            <div class="row-fluid">
                <div class="span8"><img src="/demo/templates-joomla/st_vela/images/st_vela/our_work/article-ourt-work-1.png" alt="" /></div>
                <div class="span4">
                    <h3>Project description</h3>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin eu diam lorem, id scelerisque sapien. In accumsan metus at magna vehicula placerat tempor varius ipsum. libero, non congue odio vulputate eu. Phasellus euismod magna ac est.</p>
                    <p><ul class="yt-list type-check" style=""> <li >Illustration</li>  <li >Photoshop</li> <li >Html/css</li>  </ul></p>
                </div>
            </div>				</div>
        <div class="item-content">
            <div class="row-fluid">
                <div class="span8"><div id="yt-slider-carousel" class="yt-slider-carousel carousel slide pull-none" data-ride="carousel"><div class="carousel-inner">  <div class='item'><img src='http://www.beautiful-templates.com/demo/templates-joomla/st_vela//cache/resized/ad616211d07a96772ffa249c1832ab29.png' title='Item 1' alt='Item 1' /> </div>  <div class='item'><img src='http://www.beautiful-templates.com/demo/templates-joomla/st_vela//cache/resized/13ff4a8b36b63eb686b303eba38dca3f.png' title='Item 2' alt='Item 2' /> </div>  <div class='item'><img src='http://www.beautiful-templates.com/demo/templates-joomla/st_vela//cache/resized/a97a7727100042d198eddac8e04e0827.png' title='Item 3' alt='Item 3' /> </div> </div><a class="carousel-control left" href="#yt-slider-carousel" data-slide="prev"><i class="fa fa-angle-left"></i></a><a class="carousel-control right" href="#yt-slider-carousel" data-slide="next"><i class="fa fa-angle-right"></i></a></div></div>
                <div class="span4">
                    <h3>Project description</h3>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin eu diam lorem, id scelerisque sapien. In accumsan metus at magna vehicula placerat tempor varius ipsum. libero, non congue odio vulputate eu. Phasellus euismod magna ac est.</p>
                    <p><ul class="yt-list type-check" style=""> <li >Illustration</li>  <li >Photoshop</li> <li >Html/css</li>  </ul></p>
                </div>
            </div>				</div>
        <div class="item-content">
            <div class="row-fluid">
                <div class="span8"><img src="/demo/templates-joomla/st_vela/images/st_vela/our_work/article-ourt-work-2.png" alt="" /></div>
                <div class="span4">
                    <h3>Project description</h3>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin eu diam lorem, id scelerisque sapien. In accumsan metus at magna vehicula placerat tempor varius ipsum. libero, non congue odio vulputate eu. Phasellus euismod magna ac est.</p>
                    <p><ul class="yt-list type-check" style=""> <li >Illustration</li>  <li >Photoshop</li> <li >Html/css</li>  </ul></p>
                </div>
            </div>				</div>
        <div class="item-content">
            <div class="row-fluid">
                <div class="span8"><div class="yt-vimeo pull-none" style="max-width:752px;" ><iframe src="http://player.vimeo.com/video/79695097?title=0&amp;byline=0&amp;portrait=0" width="752" height="451" ></iframe></div></div>
                <div class="span4">
                    <h3>Project description</h3>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin eu diam lorem, id scelerisque sapien. In accumsan metus at magna vehicula placerat tempor varius ipsum. libero, non congue odio vulputate eu. Phasellus euismod magna ac est.</p>
                    <p><ul class="yt-list type-check" style=""> <li >Illustration</li>  <li >Photoshop</li> <li >Html/css</li>  </ul></p>
                </div>
            </div>				</div>
        <div class="item-content">
            <div class="row-fluid">
                <div class="span8"><img src="/demo/templates-joomla/st_vela/images/st_vela/our_work/article-ourt-work-3.png" alt="" /></div>
                <div class="span4">
                    <h3>Project description</h3>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin eu diam lorem, id scelerisque sapien. In accumsan metus at magna vehicula placerat tempor varius ipsum. libero, non congue odio vulputate eu. Phasellus euismod magna ac est.</p>
                    <p><ul class="yt-list type-check" style=""> <li >Illustration</li>  <li >Photoshop</li> <li >Html/css</li>  </ul></p>
                </div>
            </div>				</div>
        <div class="item-content">
            <div class="row-fluid">
                <div class="span8"><img src="/demo/templates-joomla/st_vela/images/st_vela/our_work/article-ourt-work-2.png" alt="" /></div>
                <div class="span4">
                    <h3>Project description</h3>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin eu diam lorem, id scelerisque sapien. In accumsan metus at magna vehicula placerat tempor varius ipsum. libero, non congue odio vulputate eu. Phasellus euismod magna ac est.</p>
                    <p><ul class="yt-list type-check" style=""> <li >Illustration</li>  <li >Photoshop</li> <li >Html/css</li>  </ul></p>
                </div>
            </div>				</div>
        <div class="item-content">
            <div class="row-fluid">
                <div class="span8"><img src="/demo/templates-joomla/st_vela/images/st_vela/our_work/article-ourt-work-4.png" alt="" /></div>
                <div class="span4">
                    <h3>Project description</h3>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin eu diam lorem, id scelerisque sapien. In accumsan metus at magna vehicula placerat tempor varius ipsum. libero, non congue odio vulputate eu. Phasellus euismod magna ac est.</p>
                    <p><ul class="yt-list type-check" style=""> <li >Illustration</li>  <li >Photoshop</li> <li >Html/css</li>  </ul></p>
                </div>
            </div>				</div>
        <div class="item-content">
            <div class="row-fluid">
                <div class="span8"><img src="/demo/templates-joomla/st_vela/images/st_vela/our_work/article-ourt-work-1.png" alt="" /></div>
                <div class="span4">
                    <h3>Project description</h3>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin eu diam lorem, id scelerisque sapien. In accumsan metus at magna vehicula placerat tempor varius ipsum. libero, non congue odio vulputate eu. Phasellus euismod magna ac est.</p>
                    <p><ul class="yt-list type-check" style=""> <li >Illustration</li>  <li >Photoshop</li> <li >Html/css</li>  </ul></p>
                </div>
            </div>				</div>
        <div class="item-content">
            <div class="row-fluid">
                <div class="span8"><div class="yt-youtube pull-left" style="max-width:752px;" ><iframe src="http://www.youtube.com/embed/qd4CVvItJlo?wmode=transparent" width="752" height="451" frameborder="0" allowfullscreen></iframe></div></div>
                <div class="span4">
                    <h3>Project description</h3>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin eu diam lorem, id scelerisque sapien. In accumsan metus at magna vehicula placerat tempor varius ipsum. libero, non congue odio vulputate eu. Phasellus euismod magna ac est.</p>
                    <p><ul class="yt-list type-check" style=""> <li >Illustration</li>  <li >Photoshop</li> <li >Html/css</li>  </ul></p>
                </div>
            </div>				</div>
        <div class="item-content">
            <div class="row-fluid">
                <div class="span8"><img src="/demo/templates-joomla/st_vela/images/st_vela/our_work/article-ourt-work-4.png" alt="" /></div>
                <div class="span4">
                    <h3>Project description</h3>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin eu diam lorem, id scelerisque sapien. In accumsan metus at magna vehicula placerat tempor varius ipsum. libero, non congue odio vulputate eu. Phasellus euismod magna ac est.</p>
                    <p><ul class="yt-list type-check" style=""> <li >Illustration</li>  <li >Photoshop</li> <li >Html/css</li>  </ul></p>
                </div>
            </div>				</div>
    </div>
    <div class="navigation">
        <div class="next fa fa-chevron-circle-right" >
        </div>
        <div class="prev fa fa-chevron-circle-left" >
        </div>
    </div>

    <a href="#" id="close" class="fa-times-circle"></a>

</div>

<div class="layout-wall">


    <div class="item photography" >
        <a class="link" href="/demo/templates-joomla/st_vela/index.php/pages/blog/12-our-work/photography/10-column-image-and-text"></a>
        <div class="inner">
            <div class="media">
                <img src="/demo/templates-joomla/st_vela/images/st_vela/our_work/portfolio-10.png"  alt="Column image and text"/>
            </div>

            <div class="info image">
                <h3 class="title">
                    Column image and text												</h3>

                <div class="date">28 October 2013</div>


            </div>
        </div>

    </div>

    <div class="item logo" >
        <a class="link" href="/demo/templates-joomla/st_vela/index.php/pages/blog/10-our-work/logo/9-gallery-slider"></a>
        <div class="inner">
            <div class="media">
                <img src="/demo/templates-joomla/st_vela/images/st_vela/our_work/portfolio-9.png"  alt="Gallery slider"/>
            </div>

            <div class="info image">
                <h3 class="title">
                    Gallery slider												</h3>

                <div class="date">28 October 2013</div>


            </div>
        </div>

    </div>

    <div class="item wordpress" >
        <a class="link" href="/demo/templates-joomla/st_vela/index.php/pages/blog/11-our-work/wordpress/8-phasellus-euismod"></a>
        <div class="inner">
            <div class="media">
                <img src="/demo/templates-joomla/st_vela/images/st_vela/our_work/portfolio-8.png"  alt="Phasellus euismod"/>
            </div>

            <div class="info image">
                <h3 class="title">
                    Phasellus euismod												</h3>

                <div class="date">28 October 2013</div>


            </div>
        </div>

    </div>

    <div class="item video" >
        <a class="link" href="/demo/templates-joomla/st_vela/index.php/pages/blog/14-our-work/video/7-vimeo-video"></a>
        <div class="inner">
            <div class="media">
                <img src="/demo/templates-joomla/st_vela/images/st_vela/our_work/portfolio-6.png"  alt="Vimeo video"/>
            </div>

            <div class="info image">
                <h3 class="title">
                    Vimeo video												</h3>

                <div class="date">28 October 2013</div>


            </div>
        </div>

    </div>

    <div class="item design" >
        <a class="link" href="/demo/templates-joomla/st_vela/index.php/pages/blog/9-our-work/design/6-lorem-ipsum-dolor-sit"></a>
        <div class="inner">
            <div class="media">
                <img src="/demo/templates-joomla/st_vela/images/st_vela/our_work/portfolio-7.png"  alt="Lorem ipsum dolor sit"/>
            </div>

            <div class="info image">
                <h3 class="title">
                    Lorem ipsum dolor sit												</h3>

                <div class="date">28 October 2013</div>


            </div>
        </div>

    </div>

    <div class="item logo" >
        <a class="link" href="/demo/templates-joomla/st_vela/index.php/pages/blog/10-our-work/logo/5-proin-eu-diam-lorem"></a>
        <div class="inner">
            <div class="media">
                <img src="/demo/templates-joomla/st_vela/images/st_vela/our_work/portfolio-5.png"  alt="Proin eu diam lorem"/>
            </div>

            <div class="info image">
                <h3 class="title">
                    Proin eu diam lorem												</h3>

                <div class="date">28 October 2013</div>


            </div>
        </div>

    </div>

    <div class="item wordpress" >
        <a class="link" href="/demo/templates-joomla/st_vela/index.php/pages/blog/11-our-work/wordpress/4-ut-laoreet-dolore-magna"></a>
        <div class="inner">
            <div class="media">
                <img src="/demo/templates-joomla/st_vela/images/st_vela/our_work/portfolio-4.png"  alt="Ut laoreet dolore magna"/>
            </div>

            <div class="info image">
                <h3 class="title">
                    Ut laoreet dolore magna												</h3>

                <div class="date">28 October 2013</div>


            </div>
        </div>

    </div>

    <div class="item design" >
        <a class="link" href="/demo/templates-joomla/st_vela/index.php/pages/blog/9-our-work/design/3-sed-diam-nonummy"></a>
        <div class="inner">
            <div class="media">
                <img src="/demo/templates-joomla/st_vela/images/st_vela/our_work/portfolio-3.png"  alt="Sed diam nonummy"/>
            </div>

            <div class="info image">
                <h3 class="title">
                    Sed diam nonummy												</h3>

                <div class="date">28 October 2013</div>


            </div>
        </div>

    </div>

    <div class="item video" >
        <a class="link" href="/demo/templates-joomla/st_vela/index.php/pages/blog/14-our-work/video/2-youtube-video"></a>
        <div class="inner">
            <div class="media">
                <img src="/demo/templates-joomla/st_vela/images/st_vela/our_work/portfolio-2.png"  alt="Youtube video"/>
            </div>

            <div class="info image">
                <h3 class="title">
                    Youtube video												</h3>

                <div class="date">28 October 2013</div>


            </div>
        </div>

    </div>

    <div class="item illustrations" >
        <a class="link" href="/demo/templates-joomla/st_vela/index.php/pages/blog/13-our-work/illustrations/1-in-accumsan-metus"></a>
        <div class="inner">
            <div class="media">
                <img src="/demo/templates-joomla/st_vela/images/st_vela/our_work/portfolio-1.png"  alt="In accumsan metus"/>
            </div>

            <div class="info image">
                <h3 class="title">
                    In accumsan metus												</h3>

                <div class="date">28 October 2013</div>


            </div>
        </div>

    </div>
</div>
</div>
</div>
</div>
</div>
</div>
</body>
</html>
